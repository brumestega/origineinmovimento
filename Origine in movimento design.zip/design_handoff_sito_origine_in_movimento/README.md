# Handoff: Sito "Origine in Movimento"

## Overview
Sito vetrina/one-page-app per una creatrice olistica (numerologia, trattamenti energetici, riequilibrio degli spazi). Include home, pagine informative, due calcolatori numerologici interattivi (lead-gen via email), catalogo servizi, eventi, blog, testimonianze, form di prenotazione/contatto.

## About the Design Files
The file in this bundle (`Sito - Origine in Movimento.dc.html`) is a **design reference built in HTML** — a working prototype showing intended layout, copy, interactions and visual style. It is not production code to copy as-is. The task is to **recreate this design in the target codebase's environment** (React, Vue, plain framework, etc.) using that codebase's own component patterns, routing, and form/email infrastructure — or, if no codebase exists yet, to choose the most appropriate stack and implement it there.

## Fidelity
**High-fidelity.** Colors, typography, spacing and copy are final/near-final (aside from a few explicit `[ placeholder ]` items called out below). Recreate pixel-close using the values in this document.

## Navigation / Pages
Single-page-app style client-side routing (no real URLs) driven by a `page` state: `home`, `chisono`, `metodo`, `calcolatori`, `percorsi`, `eventi`, `blog`, `testimonianze`, `prenota`, `contatti`. Nav bar items: Chi sono, Il Metodo, Calcolatori, Percorsi, Eventi, Blog. A persistent "Prenota la call" CTA button sits at the end of the nav on every page. Clicking the logo returns home. All page switches scroll to top.

## Global Design Tokens

**Colors**
- Background (page): `#FAF6EC` (warm off-white)
- Background (alt section): `#F1E9D8`
- Card background: `#FFFFFF`, or gradient `linear-gradient(160deg,#FFFFFF,#FBF6E9)` for accent cards
- Primary text: `#241D3D`
- Body text: `#5C5570` (weight 300)
- Muted text: `#8A8398`
- Primary brand color (buttons, key CTAs): tweakable, default `#7A1B3D` (also `#2E4A3D`, `#3A3A6B`, `#8A4A2A` as alternates)
- Accent color (labels, small caps headers, icons): tweakable, default `#9C6B22` (also `#5C6B4A`, `#5A6B7A`, `#8A5A8A` as alternates)
- Dark hero overlay: `rgba(14,10,28,.55→ .88)` gradient over hero photo
- WhatsApp button green: `#25D366`

**Typography**
- Display/headings: "Cormorant Garamond" (serif), weights 400–700, italic used for emphasis words
- Body/UI: "Jost" (sans-serif), weights 300–500
- H1 sizes: 52–72px; H2: 30–40px; H3: 22–26px
- Body copy: 14–17px, line-height 1.6–1.85, weight 300
- Small caps labels (section eyebrows): 11px, letter-spacing .3–.44em, uppercase, accent color

**Shape / elevation**
- Buttons/pills: `border-radius: 40px` (fully rounded), primary color fill, white text
- Cards: `border-radius: 14–20px`, `border: 1px solid rgba(34,28,54,.08)`, `box-shadow: 0 2px 14px rgba(34,28,54,.04)`
- Inputs: `border-radius: 12px` (text fields) or `40px` (pill inputs in hero/newsletter), border `1px solid rgba(34,28,54,.15)`

## Screens

### Nav (persistent)
Sticky top bar, `rgba(250,246,236,.9)` background with blur, bottom border `1px solid rgba(34,28,54,.08)`. Logo mark: circular ring icon with a small accent-colored dot + wordmark "ORIGINE / IN MOVIMENTO" in Cormorant Garamond. Right side: 6 text nav items (13px) + pill CTA button "Prenota la call".

### Home
1. **Hero** — full-bleed photo (`hero-meduse.jpg`, jellyfish/deep-sea) with dark gradient overlay and twinkling star dots (CSS keyframe `oimTwinkle`). Eyebrow label, large serif H1 with italic second line, supporting paragraph, two CTA buttons (filled "Prenota la tua call conoscitiva gratuita", outlined "Prova i calcolatori").
2. **"Ti riconosci in questo?"** — 2×2 grid of pain-point cards, each with a ✦ glyph + short text.
3. **Calcolatori preview** — 2-column card teaser for the two calculators, each linking to the Calcolatori page.
4. **Percorso preview** — image placeholder (photo of the "percorso") + copy block + CTA to Percorsi page.
5. **Testimonianze preview** — 3-column quote cards.
6. **Newsletter** — centered card with email input + subscribe button; shows a thank-you line on success.

### Chi sono
Sticky portrait photo (`chi-sono.jpg`) left column, storytelling copy right column (2 paragraphs — currently placeholder-style prompts telling the client what to write), a "Formazione" list (3 bullet placeholders), CTA button to Prenota.

### Il Metodo
Centered intro (title + paragraph), then a vertical stepped list of 4 numbered method steps (Ascolto → Lettura dei numeri → Lavoro energetico → Integrazione), each with number, title, body. CTA at bottom.

### Calcolatori
Two-tab interactive tool (segmented pill control): "Frequenza Nome" and "Mappa dei Talenti".
- **Frequenza Nome**: Nome + Cognome text inputs → "Calcola" button → runs a Pythagorean-numerology letter-sum algorithm (see logic below) → shows big number + title + short free interpretation. Below that, an email-gated "unlock" box: enter email → reveals extended interpretation + CTA to book a call.
- **Mappa dei Talenti**: same pattern but input is a birth date; digits are summed and reduced.
- **Numerology algorithm**: each letter maps to 1–9 via a standard Pythagorean table; sum letters (name calc) or digits (birth-date calc); reduce recursively by digit-summing until ≤9, except stop at master numbers 11, 22, 33. A lookup table of 12 meanings (1–9, 11, 22, 33) provides `title`, short `base` text, and longer `extended` text (visible only after email unlock).

### Percorsi
Grid of 6 individual-session cards (title, modality badge — "Online e in presenza" / "Solo in presenza" / "Solo a domicilio" — each badge a distinct color, price, description, "Prenota →" link). Below: a highlighted premium package card ("Il Viaggio Completo", 450€/5 incontri) with a 4-column phase tracker (Incontro/Ascolto/Rivelazione/Cammino) and CTA.

### Eventi
List of event rows (date block, title, description, "Biglietto" button). Placeholder note under the list: "[ Sostituisci con i tuoi eventi reali in calendario ]" — real calendar/ticketing integration is not implemented.

### Blog
3-column post cards, each with a striped placeholder image tile (labelled "[ immagine ]" — needs real imagery), tag, title, excerpt, "Leggi →" link.

### Testimonianze
Full list (5) of quote cards with name + service tag. Placeholder note: "[ Sostituisci con le testimonianze reali definitive ]".

### Prenota
Two-column: "cosa aspettarti" bullet list card, and a dashed-border placeholder card labelled for a booking-calendar embed ("Google Calendar / Calendly da integrare qui" — **no real scheduling widget is wired up**). Footer line with direct email/phone as fallback.

### Contatti
Two-column: contact form (name, email, message textarea, submit — **not wired to any backend/email service**) and static info column (phone, email, address, hours).

### Footer (persistent)
3-column: brand blurb, "Naviga" links, contact details. Copyright line.

### WhatsApp floating button
Fixed bottom-right circular button (green `#25D366`) with WhatsApp glyph — tweakable to show/hide. Currently decorative; **no `wa.me` link is wired** — add the real deep link before shipping.

## Interactions & Behavior
- Client-side page switching, no real routing/URLs.
- Two email-gated content reveals (name calc, birth-date calc) — purely client-side state, no email actually captured/sent anywhere.
- Newsletter signup — client-side only, not connected to an ESP.
- Contact form — inputs have no state binding or submit handler; needs to be wired to a form backend or email service.
- No real booking calendar, no real WhatsApp/ticket links — all are stand-ins described above.

## State Management (as prototyped)
- `page`: current route
- `calcTab`: 'nome' | 'talenti' (default configurable)
- Name calc: `nome`, `cognome`, `nomeResult`, `nomeUnlocked`, `emailNome`
- Birth calc: `birth`, `talentoResult`, `talentoUnlocked`, `emailTal`
- Newsletter: `newsletter`, `subscribed`

## Assets
- `assets/hero-meduse.jpg` — hero background (jellyfish/deep sea photo)
- `assets/chi-sono.jpg` — portrait photo for Chi Sono page
- Several placeholder image tiles (striped pattern + monospace label) mark where real photography is still needed: Percorso preview image, Blog card thumbnails.

## Screenshots
Full-page screenshots of every screen are in `screenshots/`, in nav order: `01-home.png`, `02-chi-sono.png`, `03-il-metodo.png`, `04-calcolatori-nome.png`, `05-calcolatori-talenti.png`, `06-percorsi.png`, `07-eventi.png`, `08-blog.png`, `09-prenota.png`, `10-contatti.png`, `11-testimonianze.png`. Note these are viewport captures (above the fold on longer pages) — refer to the HTML source for full page content.

## Files
- `Sito - Origine in Movimento.dc.html` — full design/prototype source (all pages, copy, and interaction logic)
- `assets/` — the two photos referenced above
- `screenshots/` — one image per screen (see above)
